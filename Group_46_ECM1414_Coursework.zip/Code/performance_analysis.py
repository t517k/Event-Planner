import matplotlib.pyplot as plt
import numpy as np

# line graph
y_dynamic = np.array([2.579999715089798e-05, 4.679999500513077e-05, 6.089999526739121e-05, 8.799999952316284e-05, 0.00011500000953674317, 0.00023349999636411667])
y_brute = np.array([3.6500006914138796e-05, 0.0008608999997377396, 0.036752399995923044, 1.4319716999977827, 51.976652099996805, 1938.6185229999944])

# values of activities
x_num = np.array([5, 10, 15, 20, 25, 30])

y_factor = []

# bar chart - create list containing 'speedup factor'
for i in range(0, 6):
    y_factor.append((y_brute[i] / y_dynamic[i]))
    
print(y_factor)

# plot bar chart
plt.bar(x_num, y_factor)
plt.xlabel('Number of Activities')
plt.ylabel('Speedup Factor (Brute Force Time / Dynamic Time)')
plt.yscale('log') # log scale y axis
plt.show()

# plot line graph
plt.title('Execution Time: Brute Force vs Dynamic Approach')
plt.plot(x_num, y_dynamic, label='Dynamic Approach')
plt.plot(x_num, y_brute, label='Brute Force')
plt.xlabel('Number of Activities')
plt.ylabel('Execution Time')
plt.yscale('log')
plt.show()

plt.legend()
plt.show()


